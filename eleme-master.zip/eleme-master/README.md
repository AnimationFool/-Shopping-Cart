# Vue2.0仿饿了么webapp单页应用
  - 2017-06-19完成header部分,goods部分
> 项目技术栈
- vue
- vue-cli
- vue-resource
- vue-router
- es6
- stylus
- node
- webpack
- 本项目暂没有使用vuex状态管理,计划下一个项目用上,敬请关注哦!!!

## 起步
#### 1.安装node：
>`http://nodejs.cn/download/`
#### 2.git：(博主习惯使用webstrom连接git)
>`https://git-scm.com/downloads`
#### 3.从我的仓库复制代码
> $ git clone https://github.com/wq93/eleme
#### 4.安装vue脚手架工具vue-cli:
> $npm install vue-cli -g
#### 5.安装依赖
> $ npm install
> 或者 $ cnpm install(国内淘宝镜像)
#### 6.run 项目
> $ npm run dev
#### 7.发布代码
> $ npm run build
  - 发布完代码后会生成dist目录，保存着项目的所有可运行的代码。
